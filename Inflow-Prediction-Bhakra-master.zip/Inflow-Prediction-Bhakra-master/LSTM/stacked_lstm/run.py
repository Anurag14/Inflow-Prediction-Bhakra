import os
os.system("python stacked_lstm.py 1 >log1.txt")
os.system("python stacked_lstm.py 10 >log10.txt")
os.system("python stacked_lstm.py 20 >log20.txt")
os.system("python stacked_lstm.py 30 >log30.txt")
os.system("python stacked_lstm.py 40 >log40.txt")
